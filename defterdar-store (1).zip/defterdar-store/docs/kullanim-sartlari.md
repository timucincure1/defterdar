# Defterdar Kullanım Şartları
Son güncelleme: 29 Ekim 2026

1. **Hizmet:** Defterdar, kullanıcının kendi veresiye kayıtlarını cihazında tutmasını sağlayan bir araçtır.
2. **Veri sorumluluğu:** Girdiğiniz müşteri verilerinin hukuka uygunluğundan ve müşterilerinizi gerekli şekilde bilgilendirmekten siz sorumlusunuz.
3. **Yedekleme:** Veriler yalnızca cihazınızda tutulur. Cihaz kaybı, uygulamanın silinmesi veya cihaz verilerinin temizlenmesi durumunda kayıtlar geri getirilemeyebilir. Düzenli yedek almanız önerilir.
4. **Resmî belge değildir:** Uygulamadaki kayıtlar muhasebe, vergi veya hukuki delil niteliği taşıyan bir belgenin yerine geçmez.
5. **Sorumluluk sınırı:** Uygulama “olduğu gibi” sunulur. Yasaların izin verdiği ölçüde, veri kaybından veya dolaylı zararlardan sorumluluk kabul edilmez.
6. **İletişim:** timucincure@icloud.com
