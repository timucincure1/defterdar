# Mağaza metinleri (Türkçe)

## Google Play
**Uygulama adı (en fazla 30):** Defterdar: Veresiye Defteri
**Kısa açıklama (en fazla 80):** Veresiye ve borç takibi. Tek dokunuşla WhatsApp’tan nazik hatırlatma.
**Kategori:** İş (Business)   **Fiyat:** Ücretsiz   **Reklam içerir:** Hayır

**Tam açıklama:**
Defterdar, bakkal, kuaför, tamirci, kasap ve tüm esnaf için sade bir veresiye defteridir.

• Müşteri ekleyin, borç ve ödemeleri üç dokunuşta kaydedin
• Kimden ne kadar alacağınız olduğunu ana ekranda görün
• Tek dokunuşla WhatsApp’tan nazik borç hatırlatma mesajı gönderin
• İşlem geçmişi, not ve tarih bilgisi
• İnternet olmadan çalışır
• Reklam yok, hesap açmaya gerek yok
• Verileriniz yalnızca telefonunuzda saklanır, kimseyle paylaşılmaz
• Yedek alın, telefon değiştirince geri yükleyin

## App Store
**Ad (en fazla 30):** Defterdar: Veresiye Defteri
**Alt başlık (en fazla 30):** Esnaf için borç takibi
**Anahtar kelimeler (en fazla 100, virgülle, boşluksuz):** veresiye,defter,borç,alacak,esnaf,bakkal,tahsilat,müşteri,cari,hesap,kayıt
**Kategori:** İş (Business) / ikincil: Finans   **Yaş sınırı:** 4+
**Destek URL’si:** [SAYFANIZ]   **Gizlilik politikası URL’si:** [YAYINLADIĞINIZ ADRES]
**Açıklama:** Google Play tam açıklamasıyla aynı metni kullanabilirsiniz.
**İnceleme notu (Apple’a):** “Defterdar, esnafın cihaz üzerinde veresiye kaydı tuttuğu, çevrimdışı çalışan bir araçtır. Hesap gerekmez. Hatırlatma, kullanıcının cihazındaki WhatsApp’ı hazır mesajla açar. Giriş bilgisi gerekmez.”

## Veri güvenliği / gizlilik formları
- **Google Play Veri Güvenliği:** Veri toplanmıyor, paylaşılmıyor. Veriler cihazda kalıyor. Hesap silme: hesap yok. Gizlilik politikası URL’si zorunlu.
- **Apple Gizlilik Etiketi:** “Veri Toplanmıyor”.
- **İçerik derecelendirme anketi:** Şiddet, cinsellik vb. yok. Sonuç en düşük yaş grubu olmalı.
- **Hedef kitle:** 18 yaş ve üzeri (çocuklara yönelik değil).
- **Finans uygulaması beyanı (Play):** Kredi/ödeme işlemi yapmaz, yalnızca kayıt tutar. Bunu doğru işaretleyin.

## Ekran görüntüsü planı (5 adet)
1. Ana ekran, toplam alacak ve liste
2. Müşteri detayı ve bakiye
3. Borç ekleme ekranı
4. WhatsApp hatırlatma
5. Yedekleme ve gizlilik ayarı
Android: telefon emülatöründen en az 2 adet (1080x1920 civarı). iOS: 6.9" (1320x2868) ve 6.5" iPhone boyutu zorunlu olabilir; Xcode simülatörden alın.

## Google Play: İngilizce (en-US) mağaza girişi
**App name:** Defterdar: Credit Ledger
**Short description:** Track customer debts and send polite WhatsApp payment reminders.
**Full description:** Defterdar is a simple credit ledger for small shops and tradespeople. Add customers, record debts and payments in a few taps, see who owes you on one screen, and send a polite reminder via WhatsApp. Works offline, no account, no ads. Your data stays on your phone; back it up and restore it when you switch devices.

## Play Console ek beyanlar
- Uygulama erişimi: giriş yok, tüm işlevler serbest. Reklam kimliği: kullanılmıyor. Finansal özellikler: kredi/ödeme işlemi yok, yalnızca kayıt tutma.
