# Defterdar: Mağazaya yükleme rehberi

## v1.0.0 hazırlık notları (önce okuyun)
- Uygulamadaki hatalar giderildi: tutar girişinde "12.50" = 1250 olma hatası, 0,3 gibi küsurat farkıyla yanlış "borç" görünmesi, yurt dışı telefon numaraları, Android geri tuşu (uygulamayı kapatıyordu), bozuk/yanlış yedekle verinin ezilmesi.
- 20 müşteri sınırı kapatıldı (`www/index.html` içinde `FREE_LIMIT=0`; Pro gelince 20 yapın). Mağaza metni ve şartlar buna göre düzeltildi.
- Gizlilik politikası `docs/` içinde, GitHub Pages ile (Settings > Pages > /docs) yayınlanır.
- **AAB'yi bulutta üretmek (Android Studio gerekmez):** keystore üretin: `keytool -genkeypair -v -keystore release.jks -alias defterdar -keyalg RSA -keysize 2048 -validity 10000` ve yedekleyin. GitHub > Settings > Secrets'a şunları ekleyin: `KEYSTORE_BASE64` (`base64 -w0 release.jks`), `KS_PASS`, `KEY_PASS`, `KEY_ALIAS`. Actions sekmesinden "Android AAB" iş akışını çalıştırın, çıkan `defterdar-aab` dosyasını Play'e yükleyin. (Bu iş akışı henüz çalıştırılıp denenmedi; ilk çalıştırmada hata verirse log'u bana gönderin.)
- 512x512 Play simgesi: `store/play-icon-512.png`.


Bu klasör, `www/index.html` içindeki uygulamayı Capacitor ile Android ve iOS uygulamasına çeviren hazır projedir.

## 0. Hesaplar (önce bunları başlatın, zaman alır)
- Google Play Console: tek seferlik 25 USD. Kişisel hesap açtıysanız yayından önce 14 gün boyunca en az 12 test kullanıcısıyla kapalı test şart (aşağıya bakın). Şirket hesabında bu şart yok.
- Apple Developer Program: yılda 99 USD. iOS derlemesi için Mac + Xcode gerekir (Mac yoksa Codemagic, Expo EAS gibi bulut derleme hizmeti veya kiralık Mac).
- Gizlilik politikasını yayınlayın (GitHub Pages, ücretsiz site vb.) ve adresini mağazalara yazın. Metinlerde e-posta ve tarih dolduruldu.

## 1. Kurulum (bilgisayarınızda, Node.js 20+)
```
npm install
npx cap add android
npx cap add ios          # yalnızca Mac'te
npm run assets           # ikon ve açılış ekranlarını üretir
npx cap sync
```

## 2. Android
1. `npm run android` (Android Studio açılır).
2. `android/app/build.gradle` içinde `versionCode 1`, `versionName "1.0.0"` kontrol edin.
3. Build > Generate Signed App Bundle > **AAB**. Yeni bir keystore oluşturun ve **mutlaka yedekleyin** (kaybederseniz güncelleme yapamazsınız). Play App Signing’i açık bırakın.
4. Play Console > Uygulama oluştur. `store/magaza-metinleri.md` metinlerini, `store/play-feature-graphic-1024x500.png` görselini, 512x512 ikonu (`assets/icon-only.png` küçültülür) ve ekran görüntülerini yükleyin.
5. Veri güvenliği, içerik derecelendirme, hedef kitle formlarını metindeki gibi doldurun.
6. **Kapalı test:** AAB’yi Closed testing kanalına yükleyin, 12’den fazla (ideal 15-20) kişiyi e-posta ile ekleyin ve hepsi 14 gün boyunca testte kalsın. Kişi sayısı 12’nin altına düşerse süre sıfırlanabilir. Sonra “üretim erişimi için başvur”.
7. Üretim sürümü oluşturun, incelemeye gönderin.

## 3. iOS (Mac)
1. `npm run ios` (Xcode açılır). Signing & Capabilities’ten ekibinizi seçin. Bundle ID: `com.defterdar.veresiye` (alınmışsa hem `capacitor.config.json` hem Xcode’da değiştirin).
2. Product > Archive > Distribute App > App Store Connect.
3. App Store Connect’te uygulamayı oluşturun, metinleri, ekran görüntülerini, gizlilik etiketini (Veri Toplanmıyor) girin.
4. Önce TestFlight ile birkaç kişiye deneyin, sonra incelemeye gönderin.
5. **Red riski (Kural 4.2, asgari işlevsellik):** Apple, sadece web sitesi sarmalayan uygulamaları reddedebilir. Bizim lehimize olanlar: çevrimdışı çalışma, cihazda veri saklama, WhatsApp entegrasyonu, yedekleme. Yine de incelemeye gönderirken `magaza-metinleri.md` içindeki inceleme notunu yazın. Reddedilirse yerel özellik ekleyin (parmak izi/Face ID ile kilit, bildirimle hatırlatma, kişi rehberinden müşteri seçme).

## 4. Pro abonelik (henüz bağlı değil)
Dijital abonelik satarsanız Google Play Faturalandırma ve Apple uygulama içi satın alma kullanmak zorundasınız (kendi ödeme sayfanız olmaz). En kolay yol: RevenueCat + `@revenuecat/purchases-capacitor`. İlk sürümü Pro’suz yayınlayıp 20 müşteri sınırını kaldırmak ya da sınırı yükseltmek, ilk incelemeyi hızlandırır. Pro’yu 1.1 sürümünde ekleyin.

## 5. Yayın öncesi kontrol listesi
- [ ] Gizlilik politikası yayında ve adresi mağazalara girildi
- [x] E-posta ve tarih dolduruldu
- [ ] Gerçek telefonda test: borç ekle, ödeme al, WhatsApp, yedek al/yükle, sil
- [ ] Uygulamayı kapatıp açınca veri duruyor mu? iOS ve Android’de ayrı deneyin
- [ ] Keystore ve şifresi iki yerde yedekte
- [ ] Ekran görüntüleri hazır
- [ ] Uygulama adı mağazada ve TÜRKPATENT’te çakışıyor mu kontrol edildi
